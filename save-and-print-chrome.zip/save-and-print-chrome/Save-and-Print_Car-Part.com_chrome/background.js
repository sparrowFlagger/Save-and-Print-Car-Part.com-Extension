// Background service worker — handles fetches that would be blocked by CORS
// if made from the content script directly.
// The content script sends a message: { type: 'FETCH_HTML', url: '...' }
// and we respond with { html: '...' } or { error: '...' }

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'FETCH_HTML') {
        fetch(message.url)
            .then(res => {
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                return res.text();
            })
            .then(html => sendResponse({ html }))
            .catch(err => sendResponse({ error: err.message }));

        // Return true to keep the message channel open for the async response
        return true;
    }
});
