// ==UserScript==
// @name         Save & Print Car-Part.com
// @namespace    http://www.car-part.com
// @version      2.2.2
// @description  Per-row and bulk HTML export with inline settings, photo fetching, checkboxes, and back-link
// @author       You
// @match        https://www.car-part.com/cgi-bin/search.cgi*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function() {
    'use strict';

    // ─── Open arbitrary HTML in a new tab via a blob URL ──────────────────────
    // NOTE: Do NOT add rel="noopener" — that severs window.opener which some
    // pages may need. Blob tabs are sandboxed anyway.
    function openHtmlInNewTab(htmlContent) {
        const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.target = '_blank';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 40000);
    }

    // ─── Build the base HTML shell for all export pages ───────────────────────
    function getBaseHtml(title, tableContent, extraNote = '', imageMode = 'gallery', searchInfo, sourceUrl = '') {
        let bodyClass = '';
        let galleryCss = '';

        if (imageMode === 'fullsize') {
            bodyClass = 'mode-fullsize';
            galleryCss = `
                .gallery { display: flex; flex-direction: column; align-items: center; gap: 30px; margin-top: 40px; }
                .gallery-item { max-width: 90%; }
                .gallery-item img { width: 100%; max-width: 900px; height: auto; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }`;
        } else if (imageMode === 'gallery') {
            bodyClass = 'mode-gallery';
            galleryCss = `
                .gallery { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-top: 40px; }
                .gallery-item img { width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }`;
        } else {
            bodyClass = 'mode-none';
            galleryCss = `.gallery { display: none !important; }`;
        }

        let printCss = '';
        if (imageMode === 'gallery') {
            printCss = `
                @media print {
                    body { margin: 1.5cm; font-size: 11pt; }
                    .print-area, .back-link, button, .mode-banner { display: none !important; }
                    h2 { margin-top: 0; page-break-after: avoid; }
                    table { page-break-inside: auto; width: 100%; }
                    tr { page-break-inside: avoid; page-break-after: auto; }
                    .gallery { display: block; column-count: 2; column-gap: 1.2cm; orphans: 2; widows: 2; }
                    .gallery-item { break-inside: avoid-column; page-break-inside: avoid; margin-bottom: 1.2em; }
                    .gallery-item img { width: 100%; height: auto; display: block; border-radius: 4px; box-shadow: none; }
                }`;
        } else if (imageMode === 'fullsize') {
            printCss = `
                @media print {
                    body { margin: 1.5cm; font-size: 11pt; }
                    .print-area, .back-link, button, .mode-banner { display: none !important; }
                    h2 { margin-top: 0; page-break-after: avoid; }
                    table { page-break-inside: auto; }
                    tr { page-break-inside: avoid; page-break-after: auto; }
                    .gallery-item { page-break-inside: avoid; margin-bottom: 1.5em; }
                    .gallery-item img { max-width: 100%; height: auto; display: block; }
                }`;
        } else {
            printCss = `
                @media print {
                    body { margin: 1.5cm; font-size: 11pt; }
                    .print-area, .back-link, button, .gallery, .mode-banner { display: none !important; }
                    h2 { margin-top: 0; page-break-after: avoid; }
                    table { page-break-inside: auto; width: 100%; }
                    tr { page-break-inside: avoid; page-break-after: auto; }
                }`;
        }

        const backLinkHtml = sourceUrl
            ? `<div class="back-link" style="text-align:center;margin:0 0 18px;">
                   <a href="${sourceUrl}" target="_blank" style="color:#007bff;font-size:14px;text-decoration:none;">
                       &#8592; Back to original search on car-part.com
                   </a>
               </div>`
            : '';

        return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; max-width: 1600px; margin-left: auto; margin-right: auto; line-height: 1.5; color: #333; font-size: 14px; }
        h2 { text-align: center; color: #2c3e50; margin-bottom: 10px; }
        .info { text-align: center; font-size: 15px; color: #555; margin-bottom: 20px; }
        .print-area { text-align: center; margin: 20px 0 30px; padding: 15px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 6px; }
        .print-area p { margin: 0 0 12px 0; font-size: 16px; }
        #printBtn { padding: 12px 32px; font-size: 17px; font-weight: bold; background: #28a745; color: white; border: none; border-radius: 6px; cursor: pointer; }
        #printBtn:hover { background: #218838; }
        table { border-collapse: collapse; width: 100%; margin: 20px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ddd; padding: 8px 10px; text-align: left; vertical-align: middle; }
        th { background-color: #f0f4f8; font-weight: bold; color: #333; font-size: 13px; text-align: center; white-space: nowrap; }
        td { white-space: normal; word-wrap: break-word; }
        td img { max-width: 140px; height: auto; border-radius: 4px; display: block; margin: 6px auto; }
        ${galleryCss}
        ${printCss}
    </style>
</head>
<body class="${bodyClass}">
    <div class="print-area">
        <p><strong>Tip:</strong> Click below or press Ctrl+P (Cmd+P on Mac) &rarr; choose "Save as PDF"</p>
        <button id="printBtn">&#128438; Print / Save as PDF</button>
    </div>
    <h2>${title}</h2>
    <div class="info">
        <strong>Original Search:</strong> ${searchInfo.replace(/</g,'&lt;').replace(/>/g,'&gt;')}<br>
        Saved: ${new Date().toLocaleString()}
    </div>
    ${backLinkHtml}
    ${extraNote ? `<p style="text-align:center;color:#666;font-style:italic;margin:-10px 0 25px;">${extraNote}</p>` : ''}
    ${tableContent}
    <script>
        document.getElementById('printBtn').onclick = () => window.print();
    <\/script>
</body>
</html>`;
    }

    // ─── Fetch full-size photo URLs for a row ─────────────────────────────────
    // Finds ALL popupImg images in the row (not just the first), fetches each
    // popup page, and resolves to a flat array of full-size image URLs.
    function fetchRowImages(row) {
        return new Promise((resolve) => {
            const imgs = Array.from(row.querySelectorAll('img[onclick^="return popupImg"]'));
            if (!imgs.length) { resolve([]); return; }

            let pending = imgs.length;
            const allSrcs = [];

            imgs.forEach(img => {
                const match = (img.getAttribute('onclick') || '').match(/\('(.*?)'\)/);
                if (!match) { if (--pending === 0) resolve(allSrcs); return; }

                GM_xmlhttpRequest({
                    method: 'GET',
                    url: `https://imageappoh.car-part.com/image?${match[1]}`,
                    onload(res) {
                        if (res.status === 200) {
                            const doc = new DOMParser().parseFromString(res.responseText, 'text/html');
                            const script = doc.querySelector('script');
                            let srcs = [];
                            if (script) {
                                const found = script.innerHTML.match(/images\[\d+\]\.src\s*=\s*"([^"]+)"/g) || [];
                                srcs = found.map(m => m.match(/"([^"]+)"/)[1]);
                            }
                            // Fallback: derive full-size from thumbnail URLs
                            if (!srcs.length) {
                                doc.querySelectorAll('img[src*="_thumb.jpg"]').forEach(t => {
                                    srcs.push(t.src.replace('_thumb.jpg', '_web.jpg'));
                                });
                            }
                            allSrcs.push(...srcs);
                        }
                        if (--pending === 0) resolve(allSrcs);
                    },
                    onerror() { if (--pending === 0) resolve(allSrcs); }
                });
            });
        });
    }

    // ─── Main logic ───────────────────────────────────────────────────────────
    window.addEventListener('load', function() {

        // Capture the current page URL to use as a back-link in exports
        const sourceUrl = window.location.href;

        // Grab the search description shown on the results page
        let searchInfo = 'Unknown Search';
        const searchTable = document.querySelector('table[bgcolor="#e4e4e4"][width="350"]');
        if (searchTable) {
            const td = searchTable.querySelector('td[colspan="2"]');
            if (td) searchInfo = td.innerText.trim().replace(/\s+/g, ' ');
        } else {
            searchInfo = document.title.trim() || 'Unknown Search';
        }

        // Find the main results table
        let resultsTable = null;
        const candidateTables = document.querySelectorAll('table[width="100%"][border="1"][cellspacing="0"][cellpadding="4"]');
        for (const tbl of candidateTables) {
            if (Array.from(tbl.querySelectorAll('td')).some(td => td.innerText.trim().match(/\$|Stock#|Dist mile/))) {
                resultsTable = tbl;
                break;
            }
        }
        if (!resultsTable) return;

        resultsTable.style.border = '3px solid #28a745';
        resultsTable.style.marginTop = '15px';

        // Walk rows and tag each data row with the section heading above it
        function assignRowTitles() {
            let currentTitle = searchInfo || 'Unknown Row';
            resultsTable.querySelectorAll('tbody tr').forEach((row, i) => {
                if (i === 0) return;
                const cells = row.querySelectorAll('td');
                if (cells.length < 7 || cells[0].getAttribute('colspan') || cells[0].getAttribute('rowspan')) {
                    let parts = [];
                    cells.forEach(c => {
                        let t = c.innerText.trim().replace(/\s+/g, ' ');
                        if (t && !t.includes('$') && !/^\d+$/.test(t) && t !== 'X') parts.push(t);
                    });
                    if (parts.length) currentTitle = parts.join(' - ');
                } else {
                    row.dataset.rowTitle = currentTitle;
                }
            });
        }

        assignRowTitles();

        // ── Helper: find the real column header row ────────────────────────────
        function getRealHeaderRow() {
            const rows = resultsTable.querySelectorAll('tbody tr');
            if (!rows.length) return null;
            const first = rows[0];
            const cells = first.querySelectorAll('th, td');
            if (Array.from(cells).some(c => c.innerText.trim().match(/Year|Description|Damage|Stock|Price|Dealer/i))) {
                return first;
            }
            return null;
        }

        // ── Build export HTML for a single row (used by both per-row and bulk) ──
        async function buildRowHtml(row, imageMode) {
            const cells = row.querySelectorAll('td');
            const stock = cells[4]?.innerText.trim() || 'unknown';
            const rowTitle = row.dataset.rowTitle || searchInfo || 'Unknown';

            const fullImages = (imageMode !== 'none') ? await fetchRowImages(row) : [];

            let gallery = '';
            if (fullImages.length) {
                const bannerHtml = imageMode === 'fullsize' ? '<div style="background:#fff3cd;color:#856404;padding:10px 14px;margin:0 0 16px;border:1px solid #ffeeba;border-radius:8px;text-align:center;font-weight:bold;">Mode: Full-size images</div>' : imageMode === 'gallery' ? '<div style="background:#d4edda;color:#155724;padding:10px 14px;margin:0 0 16px;border:1px solid #c3e6cb;border-radius:8px;text-align:center;font-weight:bold;">Mode: Gallery (compact multi-column layout)</div>' : '';
                gallery = bannerHtml +
                    '<div class="gallery">' +
                    fullImages.map(src => `<div class="gallery-item"><img src="${src}" alt="Part Photo"></div>`).join('') +
                    '</div>';
            }

            // Build header
            let headerHtml = '';
            const realHeader = getRealHeaderRow();
            if (realHeader) {
                const hClone = realHeader.cloneNode(true);
                // Strip the 2 injected th cells on the right (checkbox last, then Export)
                hClone.querySelector('th:last-child, td:last-child')?.remove(); // Checkbox th (last)
                hClone.querySelector('th:last-child, td:last-child')?.remove(); // Export th
                hClone.querySelectorAll('td, th').forEach((c, idx) => {
                    let t = c.innerText.trim().replace(/\s+/g, ' ');
                    if (idx === 0) t = 'Year/Part/Model';
                    c.innerHTML = t;
                    c.style.whiteSpace = 'nowrap';
                    c.style.textAlign = 'center';
                });
                headerHtml = `<thead>${hClone.outerHTML}</thead>`;
            } else {
                const fake = ['Year/Part/Model', 'Description', 'Damage Code', 'Part Grade', 'Stock#', 'US Price', 'Dealer Info', 'Dist mile'];
                headerHtml = `<thead><tr>${fake.map(h => `<th>${h}</th>`).join('')}</tr></thead>`;
            }

            // Clone data row and clean up links / injected buttons
            const rowClone = row.cloneNode(true);
            const allCells = rowClone.querySelectorAll('td');
            // Dealer Info is the 7th data column (index 6 after we've removed injected cells)
            // We identify it by position — it's the second-to-last real data cell
            allCells.forEach((td, tdIdx) => {
                const isDealerCell = tdIdx === 6; // 0-based: Year, Desc, Damage, Grade, Stock, Price, Dealer, Dist
                td.querySelectorAll('a').forEach(a => {
                    const href = (a.href || '').trim();
                    const txt  = a.innerText.trim();

                    if (isDealerCell) {
                        // In dealer cell: strip junk links, keep dealer name + URL
                        if (
                            href.startsWith('tel:') ||
                            /request|quote|live|applet/i.test(href) ||
                            /request|quote|live.?chat/i.test(txt)
                        ) {
                            a.remove();
                            return;
                        }
                        if (href.startsWith('http')) {
                            // Dealer name + URL in plain matching text — no special sizing or color
                            const span = document.createElement('span');
                            span.innerHTML = `${txt} (${href})`;
                            a.replaceWith(span);
                            return;
                        }
                    }

                    // All other cells — strip to plain text, no URLs
                    a.replaceWith(document.createTextNode(txt));
                });
            });
            // Strip car-part.com's CO2e promotional text — useless in a report
            rowClone.querySelectorAll('td').forEach(td => {
                td.querySelectorAll('font[color="green"], span[style*="green"], a[href*="legend"]').forEach(el => el.remove());
                // Also catch it as plain text nodes inside a font/span tag
                td.querySelectorAll('*').forEach(el => {
                    if (/co2|carbon|estimated.*saving/i.test(el.innerText || el.textContent || '')) {
                        el.remove();
                    }
                });
            });

            // Remove the 2 injected cells on the right (checkbox last, then export button)
            rowClone.querySelector('td:last-child')?.remove(); // Checkbox cell (last)
            rowClone.querySelector('td:last-child')?.remove(); // Export button cell

            // Split into two display rows:
            // Row 1: Year/Part/Model, Description, DamageCode, Part Grade, Stock#, USPrice
            // Row 2: Dealer Info + Distance spanning full width
            const allDataCells = Array.from(rowClone.querySelectorAll('td'));
            const topCells    = allDataCells.slice(0, 6); // cols 0-5
            const dealerCell  = allDataCells[6];          // Dealer Info
            const distCell    = allDataCells[7];          // Distmile

            // Build split header — top header only covers first 6 cols
            let splitHeaderHtml = '';
            if (realHeader) {
                const hClone2 = realHeader.cloneNode(true);
                hClone2.querySelector('th:last-child, td:last-child')?.remove(); // Checkbox
                hClone2.querySelector('th:last-child, td:last-child')?.remove(); // Export
                const hCells = Array.from(hClone2.querySelectorAll('th, td'));
                // Keep only first 6
                hCells.forEach((c, i) => {
                    if (i >= 6) { c.remove(); return; }
                    let t = c.innerText.trim().replace(/\s+/g, ' ');
                    if (i === 0) t = 'Year/Part/Model';
                    c.innerHTML = t;
                    c.style.whiteSpace = 'nowrap';
                    c.style.textAlign = 'center';
                });
                splitHeaderHtml = `<thead>${hClone2.outerHTML}</thead>`;
            } else {
                const fakeTop = ['Year/Part/Model','Description','Damage Code','Part Grade','Stock#','US Price'];
                splitHeaderHtml = `<thead><tr>${fakeTop.map(h=>`<th>${h}</th>`).join('')}</tr></thead>`;
            }

            const topRowHtml = `<tr>${topCells.map(td => td.outerHTML).join('')}</tr>`;

            // Second table: Dealer Info + Distance with proper column headers
            const dealerHtml = dealerCell ? dealerCell.outerHTML : '<td></td>';
            const distHtml   = distCell   ? distCell.outerHTML   : '<td></td>';
            const bottomHeaderHtml = `<thead><tr>
                <th style="text-align:center;white-space:nowrap;background:#f0f4f8;">Dealer Info</th>
                <th style="text-align:center;white-space:nowrap;background:#f0f4f8;width:60px;">Dist mile</th>
            </tr></thead>`;
            const bottomRowHtml = `<tr>${dealerHtml}${distHtml}</tr>`;

            const splitTableHtml = `<table>${splitHeaderHtml}<tbody>${topRowHtml}</tbody></table>
                <table style="margin-top:8px;">${bottomHeaderHtml}<tbody>${bottomRowHtml}</tbody></table>`;

            return {
                stock,
                rowTitle,
                tableHtml: `${splitTableHtml}${gallery}`
            };
        }

        // ── Settings modal ─────────────────────────────────────────────────────
        const settingsOverlay = document.createElement('div');
        settingsOverlay.style.cssText = `
            display:none; position:fixed; top:0; left:0; width:100%; height:100%;
            background:rgba(0,0,0,0.55); z-index:999999; align-items:center; justify-content:center;`;

        const settingsBox = document.createElement('div');
        settingsBox.style.cssText = `
            background:white; border-radius:12px; padding:32px 36px; max-width:520px; width:90%;
            box-shadow:0 8px 32px rgba(0,0,0,0.25); font-family:Arial,sans-serif; color:#333;`;

        settingsBox.innerHTML = `
            <h2 style="margin:0 0 6px;color:#2c3e50;font-size:20px;">Car-Part Export Settings <span style="font-size:13px;color:#888;">v2.2.1</span></h2>
            <p style="margin:0 0 20px;color:#555;font-size:14px;">Default image mode used automatically when clicking "Save Result (HTML)":</p>
            <label style="display:block;margin:10px 0;font-size:15px;cursor:pointer;">
                <input type="radio" name="cpDefaultMode" value="fullsize" style="margin-right:8px;transform:scale(1.2);"> Full-size images (larger, stacked vertically)
            </label>
            <label style="display:block;margin:10px 0;font-size:15px;cursor:pointer;">
                <input type="radio" name="cpDefaultMode" value="gallery" style="margin-right:8px;transform:scale(1.2);"> Gallery (compact multi-column layout – recommended)
            </label>
            <label style="display:block;margin:10px 0;font-size:15px;cursor:pointer;">
                <input type="radio" name="cpDefaultMode" value="none" style="margin-right:8px;transform:scale(1.2);"> No images (fastest, smallest file, reliable offline)
            </label>
            <div style="margin-top:24px;display:flex;gap:12px;align-items:center;">
                <button id="cpSaveBtn" style="padding:10px 24px;background:#28a745;color:white;border:none;border-radius:6px;font-size:15px;font-weight:bold;cursor:pointer;">Save</button>
                <button id="cpCancelBtn" style="padding:10px 20px;background:#6c757d;color:white;border:none;border-radius:6px;font-size:15px;cursor:pointer;">Cancel</button>
                <span id="cpSavedMsg" style="color:#155724;background:#d4edda;padding:6px 14px;border-radius:6px;font-size:14px;display:none;">Saved!</span>
            </div>
            <p style="margin:18px 0 0;font-size:12px;color:#aaa;">More options coming in future updates.</p>`;

        settingsOverlay.appendChild(settingsBox);
        document.body.appendChild(settingsOverlay);

        settingsOverlay.addEventListener('click', (e) => {
            if (e.target === settingsOverlay) settingsOverlay.style.display = 'none';
        });
        settingsBox.querySelector('#cpCancelBtn').onclick = () => settingsOverlay.style.display = 'none';
        settingsBox.querySelector('#cpSaveBtn').onclick = () => {
            const selected = settingsBox.querySelector('input[name="cpDefaultMode"]:checked')?.value || 'gallery';
            GM_setValue('defaultImageMode', selected);
            // Update the Settings button label to reflect new mode
            updateSettingsBtnLabel(selected);
            const msg = settingsBox.querySelector('#cpSavedMsg');
            msg.style.display = 'inline';
            setTimeout(() => { msg.style.display = 'none'; settingsOverlay.style.display = 'none'; }, 1200);
        };

        // ── Toolbar panel ──────────────────────────────────────────────────────
        const globalContainer = document.createElement('div');
        globalContainer.style.cssText = `
            margin:14px 0 22px 0; background:#f0f4f8;
            border:1px solid #c8d6e5; border-left:4px solid #007bff;
            border-radius:6px; padding:0;
            font-family:Arial,sans-serif; overflow:hidden;`;

        // Header strip: title left, search info right
        const panelHeader = document.createElement('div');
        panelHeader.style.cssText = `
            display:flex; align-items:center; justify-content:space-between;
            background:#dde8f5; border-bottom:1px solid #c8d6e5;
            padding:7px 14px; flex-wrap:wrap; gap:6px;`;

        const panelLabel = document.createElement('span');
        panelLabel.textContent = '📦 Save & Print Car-Part.com';
        panelLabel.style.cssText = 'font-weight:bold; font-size:13px; color:#1a2e45; white-space:nowrap;';

        const searchNote = document.createElement('span');
        searchNote.innerHTML = `<span style="color:#555;font-size:12px;">Search: <strong style="color:#1a2e45;">${searchInfo}</strong></span>`;
        searchNote.style.cssText = 'white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:500px;';

        panelHeader.appendChild(panelLabel);
        panelHeader.appendChild(searchNote);
        globalContainer.appendChild(panelHeader);

        // Button row
        const buttonRow = document.createElement('div');
        buttonRow.style.cssText = 'display:flex; align-items:center; gap:10px; padding:10px 14px; flex-wrap:wrap;';
        globalContainer.appendChild(buttonRow);

        // Settings button — shows current mode in label
        const settingsBtn = document.createElement('button');
        function updateSettingsBtnLabel(mode) {
            const labels = { gallery: 'Gallery', fullsize: 'Full-size', none: 'No images' };
            settingsBtn.textContent = `⚙ Settings (${labels[mode] || mode})`;
        }
        updateSettingsBtnLabel(GM_getValue('defaultImageMode', 'gallery'));
        settingsBtn.style.cssText = 'padding:8px 16px; background:#6c757d; color:white; border:1px solid #5a6268; border-radius:4px; font-weight:bold; cursor:pointer;';
        settingsBtn.onclick = () => {
            const currentMode = GM_getValue('defaultImageMode', 'gallery');
            const radio = settingsBox.querySelector(`input[value="${currentMode}"]`);
            if (radio) radio.checked = true;
            settingsOverlay.style.display = 'flex';
        };
        buttonRow.appendChild(settingsBtn);

        // Save Selected button (hidden until checkboxes are ticked)
        const saveSelectedBtn = document.createElement('button');
        saveSelectedBtn.textContent = '💾 Save Selected (0)';
        saveSelectedBtn.style.cssText = 'padding:8px 16px; background:#28a745; color:white; border:1px solid #1e7e34; border-radius:4px; font-weight:bold; cursor:pointer; display:none;';
        saveSelectedBtn.onclick = async () => {
            const checked = Array.from(resultsTable.querySelectorAll('input.cp-row-checkbox:checked'));
            if (!checked.length) return;
            const imageMode = GM_getValue('defaultImageMode', 'gallery');

            saveSelectedBtn.disabled = true;
            saveSelectedBtn.textContent = `⏳ Exporting ${checked.length} row(s)...`;

            for (const cb of checked) {
                const row = cb.closest('tr');
                if (!row) continue;
                const { stock, rowTitle, tableHtml } = await buildRowHtml(row, imageMode);
                const htmlTitle = `Stock #${stock} - ${rowTitle}`;
                openHtmlInNewTab(getBaseHtml(htmlTitle, tableHtml,
                    imageMode !== 'none' ? 'Images should load while online.' : 'Text-only export.',
                    imageMode, searchInfo, sourceUrl));
            }

            saveSelectedBtn.disabled = false;
            updateSaveSelectedBtn();
        };
        buttonRow.appendChild(saveSelectedBtn);

        // Save All button
        const dlHtmlGlobalBtn = document.createElement('button');
        dlHtmlGlobalBtn.textContent = '📄 Save Search Results';
        dlHtmlGlobalBtn.style.cssText = 'padding:8px 16px; background:#007bff; color:white; border:1px solid #0062cc; border-radius:4px; font-weight:bold; cursor:pointer;';
        dlHtmlGlobalBtn.onclick = async () => {
            const imageMode = GM_getValue('defaultImageMode', 'gallery');
            const clone = resultsTable.cloneNode(true);
            clone.querySelectorAll('td:last-child, button, th:last-child, input[type="checkbox"]').forEach(el => el.remove());
            clone.querySelector('tbody tr:first-child')?.remove();
            if (imageMode === 'none') {
                clone.querySelectorAll('img').forEach(img => img.remove());
            }
            const html = getBaseHtml(
                `Full Results - ${searchInfo}`,
                clone.outerHTML,
                imageMode !== 'none' ? 'Images shown are thumbnails from the live page.' : 'Text-only export – no images included.',
                imageMode, searchInfo, sourceUrl
            );
            openHtmlInNewTab(html);
        };
        buttonRow.appendChild(dlHtmlGlobalBtn);

        resultsTable.parentNode.insertBefore(globalContainer, resultsTable);

        // ── Add Export column header ───────────────────────────────────────────
        const headerRow = getRealHeaderRow();
        if (headerRow) {
            // Export header cell
            const thEx = document.createElement('th');
            thEx.textContent = 'Export';
            thEx.style.cssText = 'text-align:center; white-space:nowrap;';
            headerRow.appendChild(thEx);

            // Checkbox header cell (select-all) — very last column
            const thCb = document.createElement('th');
            thCb.style.cssText = 'text-align:center; white-space:nowrap;';
            thCb.innerHTML = `<input type="checkbox" id="cp-select-all" title="Select all rows" style="transform:scale(1.3); cursor:pointer;">`;
            headerRow.appendChild(thCb);

            // Select-all checkbox logic
            document.getElementById('cp-select-all').addEventListener('change', function() {
                resultsTable.querySelectorAll('input.cp-row-checkbox').forEach(cb => cb.checked = this.checked);
                updateSaveSelectedBtn();
            });
        }

        // Update the Save Selected button count / visibility
        function updateSaveSelectedBtn() {
            const count = resultsTable.querySelectorAll('input.cp-row-checkbox:checked').length;
            if (count > 0) {
                saveSelectedBtn.style.display = 'inline-block';
                saveSelectedBtn.textContent = `💾 Save Selected (${count})`;
            } else {
                saveSelectedBtn.style.display = 'none';
            }
        }

        // ── Add per-row checkbox + export button ───────────────────────────────
        resultsTable.querySelectorAll('tbody tr').forEach((row, index) => {
            if (index === 0) return;
            const cells = row.querySelectorAll('td');
            if (cells.length < 7) return;

            const stock = cells[4]?.innerText.trim() || '?';
            const hasPhoto = !!row.querySelector('img[onclick^="return popupImg"]');

            // Export button cell (appended, right side)
            const btnCell = document.createElement('td');
            btnCell.style.cssText = 'text-align:center; vertical-align:middle; min-width:160px; padding:6px 10px;';

            const saveBtn = document.createElement('button');
            saveBtn.textContent = `Save #${stock}`;
            saveBtn.title = hasPhoto ? 'This row has photos' : 'No photos for this row';
            saveBtn.style.cssText = `
                padding:5px 18px; min-width:120px; font-size:13px; font-weight:bold;
                color:white; border-radius:4px; cursor:pointer;
                border:${hasPhoto ? '1px solid #0062cc' : '1px solid #5a6268'};
                background:${hasPhoto ? '#007bff' : '#5a9bd4'};`;

            saveBtn.onclick = async () => {
                const imageMode = GM_getValue('defaultImageMode', 'gallery');
                saveBtn.disabled = true;
                saveBtn.textContent = '⏳ Loading...';

                const { stock: s, rowTitle, tableHtml } = await buildRowHtml(row, imageMode);
                const htmlTitle = `Stock #${s} - ${rowTitle}`;
                openHtmlInNewTab(getBaseHtml(htmlTitle, tableHtml,
                    imageMode !== 'none' ? 'Images should load while online.' : 'Text-only export.',
                    imageMode, searchInfo, sourceUrl));

                saveBtn.disabled = false;
                saveBtn.textContent = `Save #${s}`;
            };

            btnCell.appendChild(saveBtn);
            row.appendChild(btnCell);

            // Checkbox cell — very last column
            const cbCell = document.createElement('td');
            cbCell.style.cssText = 'text-align:center; vertical-align:middle; padding:0 10px;';
            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.className = 'cp-row-checkbox';
            cb.style.cssText = 'transform:scale(1.3); cursor:pointer;';
            cb.addEventListener('change', updateSaveSelectedBtn);
            cbCell.appendChild(cb);
            row.appendChild(cbCell);
        });

    });
})();