// Background script - handles CORS-free fetches for the content script.
// Uses browser.* (Firefox) with fallback to chrome.*

var api = typeof browser !== 'undefined' ? browser : chrome;

api.runtime.onMessage.addListener(function(message, sender, sendResponse) {

    if (message.type === 'PING') {
        sendResponse({ status: 'awake' });
        return true;
    }

    if (message.type === 'FETCH_HTML') {
        fetch(message.url)
            .then(function(res) {
                if (!res.ok) throw new Error('HTTP ' + res.status);
                return res.text();
            })
            .then(function(html) { sendResponse({ html: html }); })
            .catch(function(err) { sendResponse({ error: err.message }); });
        return true;
    }
});
