// Car-Part.com Save & Print - Firefox Extension v2.2.2
// All comments are ASCII only - Firefox rejects non-ASCII chars in JS files.

'use strict';

// --- Storage helpers ---------------------------------------------------------
// Uses browser.* if available (Firefox), falls back to chrome.* (Chrome/Edge).
// Uses storage.local - more reliable than storage.sync on Firefox without sign-in.
var _api = typeof browser !== 'undefined' ? browser : chrome;

function storageGet(key, defaultValue) {
    return new Promise(function(resolve) {
        _api.storage.local.get({ [key]: defaultValue }, function(result) {
            resolve(result[key]);
        });
    });
}

function storageSet(key, value) {
    return new Promise(function(resolve) {
        _api.storage.local.set({ [key]: value }, resolve);
    });
}

// --- Wake background script before it is needed ------------------------------
// Firefox MV2 background scripts can be idle. Pinging on load wakes them early.
async function wakeBackground() {
    for (var i = 0; i < 5; i++) {
        try {
            await _api.runtime.sendMessage({ type: 'PING' });
            return;
        } catch(e) {
            await new Promise(function(r) { setTimeout(r, 200); });
        }
    }
}

// --- Open HTML in a new tab via blob URL ------------------------------------
function openHtmlInNewTab(htmlContent) {
    var blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function() { URL.revokeObjectURL(url); }, 40000);
}

// --- Build the base HTML shell for export pages -----------------------------
function getBaseHtml(title, tableContent, extraNote, imageMode, searchInfo, sourceUrl) {
    extraNote = extraNote || '';
    imageMode = imageMode || 'gallery';
    sourceUrl = sourceUrl || '';

    var bodyClass = '';
    var galleryCss = '';
    if (imageMode === 'fullsize') {
        bodyClass = 'mode-fullsize';
        galleryCss = '.gallery{display:flex;flex-direction:column;align-items:center;gap:30px;margin-top:40px;}' +
            '.gallery-item{max-width:90%;}' +
            '.gallery-item img{width:100%;max-width:900px;height:auto;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);}';
    } else if (imageMode === 'gallery') {
        bodyClass = 'mode-gallery';
        galleryCss = '.gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin-top:40px;}' +
            '.gallery-item img{width:100%;height:auto;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);}';
    } else {
        bodyClass = 'mode-none';
        galleryCss = '.gallery{display:none!important;}';
    }

    var printCss = '';
    if (imageMode === 'gallery') {
        printCss = '@media print{body{margin:1.5cm;font-size:11pt;}' +
            '.print-area,.back-link,button,.mode-banner{display:none!important;}' +
            'h2{margin-top:0;page-break-after:avoid;}' +
            'table{page-break-inside:auto;width:100%;}' +
            'tr{page-break-inside:avoid;page-break-after:auto;}' +
            '.gallery{display:block;column-count:2;column-gap:1.2cm;}' +
            '.gallery-item{break-inside:avoid-column;page-break-inside:avoid;margin-bottom:1.2em;}' +
            '.gallery-item img{width:100%;height:auto;display:block;border-radius:4px;box-shadow:none;}}';
    } else if (imageMode === 'fullsize') {
        printCss = '@media print{body{margin:1.5cm;font-size:11pt;}' +
            '.print-area,.back-link,button,.mode-banner{display:none!important;}' +
            'h2{margin-top:0;page-break-after:avoid;}' +
            'table{page-break-inside:auto;}' +
            'tr{page-break-inside:avoid;page-break-after:auto;}' +
            '.gallery-item{page-break-inside:avoid;margin-bottom:1.5em;}' +
            '.gallery-item img{max-width:100%;height:auto;display:block;}}';
    } else {
        printCss = '@media print{body{margin:1.5cm;font-size:11pt;}' +
            '.print-area,.back-link,button,.gallery,.mode-banner{display:none!important;}' +
            'h2{margin-top:0;page-break-after:avoid;}' +
            'table{page-break-inside:auto;width:100%;}' +
            'tr{page-break-inside:avoid;page-break-after:auto;}}';
    }

    var backLinkHtml = sourceUrl
        ? '<div class="back-link" style="text-align:center;margin:0 0 18px;">' +
          '<a href="' + sourceUrl + '" target="_blank" style="color:#007bff;font-size:14px;text-decoration:none;">' +
          '&#8592; Back to original search on car-part.com</a></div>'
        : '';

    var safeSearch = searchInfo.replace(/</g, '&lt;').replace(/>/g, '&gt;');

    return '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n' +
        '<title>' + title + '</title>\n<style>\n' +
        'body{font-family:Arial,sans-serif;margin:30px;max-width:1600px;margin-left:auto;margin-right:auto;line-height:1.5;color:#333;font-size:14px;}\n' +
        'h2{text-align:center;color:#2c3e50;margin-bottom:10px;}\n' +
        '.info{text-align:center;font-size:15px;color:#555;margin-bottom:20px;}\n' +
        '.print-area{text-align:center;margin:20px 0 30px;padding:15px;background:#f8f9fa;border:1px solid #dee2e6;border-radius:6px;}\n' +
        '.print-area p{margin:0 0 12px 0;font-size:16px;}\n' +
        '#printBtn{padding:12px 32px;font-size:17px;font-weight:bold;background:#28a745;color:white;border:none;border-radius:6px;cursor:pointer;}\n' +
        '#printBtn:hover{background:#218838;}\n' +
        'table{border-collapse:collapse;width:100%;margin:20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.1);}\n' +
        'th,td{border:1px solid #ddd;padding:8px 10px;text-align:left;vertical-align:middle;}\n' +
        'th{background-color:#f0f4f8;font-weight:bold;color:#333;font-size:13px;text-align:center;white-space:nowrap;}\n' +
        'td{white-space:normal;word-wrap:break-word;}\n' +
        'td img{max-width:140px;height:auto;border-radius:4px;display:block;margin:6px auto;}\n' +
        galleryCss + '\n' + printCss + '\n</style>\n</head>\n' +
        '<body class="' + bodyClass + '">\n' +
        '<div class="print-area"><p><strong>Tip:</strong> Click below or press Ctrl+P &rarr; choose "Save as PDF"</p>' +
        '<button id="printBtn">Print / Save as PDF</button></div>\n' +
        '<h2>' + title + '</h2>\n' +
        '<div class="info"><strong>Original Search:</strong> ' + safeSearch + '<br>Saved: ' + new Date().toLocaleString() + '</div>\n' +
        backLinkHtml + '\n' +
        (extraNote ? '<p style="text-align:center;color:#666;font-style:italic;margin:-10px 0 25px;">' + extraNote + '</p>\n' : '') +
        tableContent + '\n' +
        '<script>document.getElementById(\'printBtn\').onclick=function(){window.print();};<\/script>\n' +
        '</body>\n</html>';
}

// --- Fetch full-size photo URLs for a row ------------------------------------
// Routes through background script to avoid CORS restrictions.
async function fetchRowImages(row) {
    var imgs = Array.from(row.querySelectorAll('img[onclick^="return popupImg"]'));
    if (!imgs.length) return [];
    var allSrcs = [];

    await Promise.all(imgs.map(async function(img) {
        var match = (img.getAttribute('onclick') || '').match(/\('(.*?)'\)/);
        if (!match) return;
        try {
            var url = 'https://imageappoh.car-part.com/image?' + match[1];
            var response = null;
            for (var attempt = 0; attempt < 3; attempt++) {
                try {
                    response = await _api.runtime.sendMessage({ type: 'FETCH_HTML', url: url });
                    if (response && (response.html || response.error)) break;
                } catch(msgErr) {
                    await new Promise(function(r) { setTimeout(r, 300 * (attempt + 1)); });
                }
            }
            if (!response || response.error || !response.html) return;
            var doc = new DOMParser().parseFromString(response.html, 'text/html');
            var script = doc.querySelector('script');
            var srcs = [];
            if (script) {
                var found = script.innerHTML.match(/images\[\d+\]\.src\s*=\s*"([^"]+)"/g) || [];
                srcs = found.map(function(m) { return m.match(/"([^"]+)"/)[1]; });
            }
            if (!srcs.length) {
                doc.querySelectorAll('img[src*="_thumb.jpg"]').forEach(function(t) {
                    srcs.push(t.src.replace('_thumb.jpg', '_web.jpg'));
                });
            }
            allSrcs.push.apply(allSrcs, srcs);
        } catch(e) {
            console.warn('[Car-Part.com Save & Print] Failed to fetch photo:', e);
        }
    }));
    return allSrcs;
}

// --- Main logic - runs after page load ---------------------------------------
window.addEventListener('load', async function() {
    wakeBackground();

    var sourceUrl = window.location.href;
    var searchInfo = 'Unknown Search';
    var searchTable = document.querySelector('table[bgcolor="#e4e4e4"][width="350"]');
    if (searchTable) {
        var td = searchTable.querySelector('td[colspan="2"]');
        if (td) searchInfo = td.innerText.trim().replace(/\s+/g, ' ');
    } else {
        searchInfo = document.title.trim() || 'Unknown Search';
    }

    var resultsTable = null;
    var candidateTables = document.querySelectorAll('table[width="100%"][border="1"][cellspacing="0"][cellpadding="4"]');
    for (var i = 0; i < candidateTables.length; i++) {
        var tbl = candidateTables[i];
        if (Array.from(tbl.querySelectorAll('td')).some(function(td) { return td.innerText.trim().match(/\$|Stock#|Dist mile/); })) {
            resultsTable = tbl;
            break;
        }
    }
    if (!resultsTable) return;

    resultsTable.style.border = '3px solid #28a745';
    resultsTable.style.marginTop = '15px';

    function assignRowTitles() {
        var currentTitle = searchInfo;
        resultsTable.querySelectorAll('tbody tr').forEach(function(row, i) {
            if (i === 0) return;
            var cells = row.querySelectorAll('td');
            if (cells.length < 7 || cells[0].getAttribute('colspan') || cells[0].getAttribute('rowspan')) {
                var parts = [];
                cells.forEach(function(c) {
                    var t = c.innerText.trim().replace(/\s+/g, ' ');
                    if (t && !t.includes('$') && !/^\d+$/.test(t) && t !== 'X') parts.push(t);
                });
                if (parts.length) currentTitle = parts.join(' - ');
            } else {
                row.dataset.rowTitle = currentTitle;
            }
        });
    }
    assignRowTitles();

    function getRealHeaderRow() {
        var rows = resultsTable.querySelectorAll('tbody tr');
        if (!rows.length) return null;
        var cells = rows[0].querySelectorAll('th, td');
        if (Array.from(cells).some(function(c) { return c.innerText.trim().match(/Year|Description|Damage|Stock|Price|Dealer/i); })) {
            return rows[0];
        }
        return null;
    }

    async function buildRowHtml(row, imageMode) {
        var cells = row.querySelectorAll('td');
        var stock = cells[4] ? cells[4].innerText.trim() : 'unknown';
        var rowTitle = row.dataset.rowTitle || searchInfo || 'Unknown';
        var realHeader = getRealHeaderRow();
        var fullImages = (imageMode !== 'none') ? await fetchRowImages(row) : [];

        var gallery = '';
        if (fullImages.length) {
            var bannerHtml = '';
            if (imageMode === 'fullsize') {
                bannerHtml = '<div style="background:#fff3cd;color:#856404;padding:10px 14px;margin:0 0 16px;border:1px solid #ffeeba;border-radius:8px;text-align:center;font-weight:bold;">Mode: Full-size images</div>';
            } else if (imageMode === 'gallery') {
                bannerHtml = '<div style="background:#d4edda;color:#155724;padding:10px 14px;margin:0 0 16px;border:1px solid #c3e6cb;border-radius:8px;text-align:center;font-weight:bold;">Mode: Gallery (compact multi-column layout)</div>';
            }
            gallery = bannerHtml + '<div class="gallery">' +
                fullImages.map(function(src) { return '<div class="gallery-item"><img src="' + src + '" alt="Part Photo"></div>'; }).join('') +
                '</div>';
        }

        var splitHeaderHtml = '';
        if (realHeader) {
            var hClone = realHeader.cloneNode(true);
            var lastTh = hClone.querySelector('th:last-child,td:last-child');
            if (lastTh) lastTh.remove();
            lastTh = hClone.querySelector('th:last-child,td:last-child');
            if (lastTh) lastTh.remove();
            var hCells = Array.from(hClone.querySelectorAll('th,td'));
            hCells.forEach(function(c, i) {
                if (i >= 6) { c.remove(); return; }
                var t = c.innerText.trim().replace(/\s+/g, ' ');
                if (i === 0) t = 'Year/Part/Model';
                c.innerHTML = t;
                c.style.whiteSpace = 'nowrap';
                c.style.textAlign = 'center';
            });
            splitHeaderHtml = '<thead>' + hClone.outerHTML + '</thead>';
        } else {
            splitHeaderHtml = '<thead><tr><th>Year/Part/Model</th><th>Description</th><th>Damage Code</th><th>Part Grade</th><th>Stock#</th><th>US Price</th></tr></thead>';
        }

        var rowClone = row.cloneNode(true);
        var allCells = rowClone.querySelectorAll('td');
        allCells.forEach(function(td, tdIdx) {
            var isDealerCell = tdIdx === 6;
            td.querySelectorAll('a').forEach(function(a) {
                var href = (a.href || '').trim();
                var txt = a.innerText.trim();
                if (isDealerCell) {
                    if (href.startsWith('tel:') || /request|quote|live|applet/i.test(href) || /request|quote|live.?chat/i.test(txt)) {
                        a.remove(); return;
                    }
                    if (href.startsWith('http')) {
                        var span = document.createElement('span');
                        span.innerHTML = txt + ' (' + href + ')';
                        a.replaceWith(span); return;
                    }
                }
                a.replaceWith(document.createTextNode(txt));
            });
        });

        rowClone.querySelectorAll('td').forEach(function(td) {
            td.querySelectorAll('font[color="green"],span[style*="green"],a[href*="legend"]').forEach(function(el) { el.remove(); });
            td.querySelectorAll('*').forEach(function(el) {
                if (/co2|carbon|estimated.*saving/i.test(el.innerText || el.textContent || '')) el.remove();
            });
        });

        var c1 = rowClone.querySelector('td:last-child'); if (c1) c1.remove();
        var c2 = rowClone.querySelector('td:last-child'); if (c2) c2.remove();

        var dataCells = Array.from(rowClone.querySelectorAll('td'));
        var topCells = dataCells.slice(0, 6);
        var dealerCell = dataCells[6];
        var distCell = dataCells[7];

        var topRowHtml = '<tr>' + topCells.map(function(td) { return td.outerHTML; }).join('') + '</tr>';
        var dealerHtml = dealerCell ? dealerCell.outerHTML : '<td></td>';
        var distHtml = distCell ? distCell.outerHTML : '<td></td>';
        var bottomHeader = '<thead><tr>' +
            '<th style="text-align:center;white-space:nowrap;background:#f0f4f8;">Dealer Info</th>' +
            '<th style="text-align:center;white-space:nowrap;background:#f0f4f8;width:60px;">Dist mile</th>' +
            '</tr></thead>';

        return {
            stock: stock,
            rowTitle: rowTitle,
            tableHtml: '<table>' + splitHeaderHtml + '<tbody>' + topRowHtml + '</tbody></table>' +
                '<table style="margin-top:8px;">' + bottomHeader + '<tbody><tr>' + dealerHtml + distHtml + '</tr></tbody></table>' +
                gallery
        };
    }

    // --- Settings modal -------------------------------------------------------
    var settingsOverlay = document.createElement('div');
    settingsOverlay.style.cssText = 'display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.55);z-index:999999;align-items:center;justify-content:center;';
    var settingsBox = document.createElement('div');
    settingsBox.style.cssText = 'background:white;border-radius:12px;padding:32px 36px;max-width:520px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.25);font-family:Arial,sans-serif;color:#333;';
    settingsBox.innerHTML =
        '<h2 style="margin:0 0 6px;color:#2c3e50;font-size:20px;">Car-Part Export Settings <span style="font-size:13px;color:#888;">v2.2.2</span></h2>' +
        '<p style="margin:0 0 20px;color:#555;font-size:14px;">Default image mode:</p>' +
        '<label style="display:block;margin:10px 0;font-size:15px;cursor:pointer;"><input type="radio" name="cpDefaultMode" value="fullsize" style="margin-right:8px;"> Full-size images</label>' +
        '<label style="display:block;margin:10px 0;font-size:15px;cursor:pointer;"><input type="radio" name="cpDefaultMode" value="gallery" style="margin-right:8px;"> Gallery (recommended)</label>' +
        '<label style="display:block;margin:10px 0;font-size:15px;cursor:pointer;"><input type="radio" name="cpDefaultMode" value="none" style="margin-right:8px;"> No images (offline-safe)</label>' +
        '<div style="margin-top:24px;display:flex;gap:12px;align-items:center;">' +
        '<button id="cpSaveBtn" style="padding:10px 24px;background:#28a745;color:white;border:none;border-radius:6px;font-size:15px;font-weight:bold;cursor:pointer;">Save</button>' +
        '<button id="cpCancelBtn" style="padding:10px 20px;background:#6c757d;color:white;border:none;border-radius:6px;font-size:15px;cursor:pointer;">Cancel</button>' +
        '<span id="cpSavedMsg" style="color:#155724;background:#d4edda;padding:6px 14px;border-radius:6px;font-size:14px;display:none;">Saved!</span></div>';
    settingsOverlay.appendChild(settingsBox);
    document.body.appendChild(settingsOverlay);
    settingsOverlay.addEventListener('click', function(e) { if (e.target === settingsOverlay) settingsOverlay.style.display = 'none'; });
    settingsBox.querySelector('#cpCancelBtn').onclick = function() { settingsOverlay.style.display = 'none'; };
    settingsBox.querySelector('#cpSaveBtn').onclick = async function() {
        var sel = settingsBox.querySelector('input[name="cpDefaultMode"]:checked');
        var mode = sel ? sel.value : 'gallery';
        await storageSet('defaultImageMode', mode);
        updateSettingsBtnLabel(mode);
        var msg = settingsBox.querySelector('#cpSavedMsg');
        msg.style.display = 'inline';
        setTimeout(function() { msg.style.display = 'none'; settingsOverlay.style.display = 'none'; }, 1200);
    };

    // --- Toolbar -------------------------------------------------------------
    var globalContainer = document.createElement('div');
    globalContainer.style.cssText = 'margin:14px 0 22px 0;background:#f0f4f8;border:1px solid #c8d6e5;border-left:4px solid #007bff;border-radius:6px;padding:0;font-family:Arial,sans-serif;overflow:hidden;';
    var panelHeader = document.createElement('div');
    panelHeader.style.cssText = 'display:flex;align-items:center;justify-content:space-between;background:#dde8f5;border-bottom:1px solid #c8d6e5;padding:7px 14px;flex-wrap:wrap;gap:6px;';
    var panelLabel = document.createElement('span');
    panelLabel.textContent = 'Car-Part.com Save & Print';
    panelLabel.style.cssText = 'font-weight:bold;font-size:13px;color:#1a2e45;white-space:nowrap;';
    var searchNote = document.createElement('span');
    searchNote.innerHTML = '<span style="color:#555;font-size:12px;">Search: <strong style="color:#1a2e45;">' + searchInfo + '</strong></span>';
    panelHeader.appendChild(panelLabel);
    panelHeader.appendChild(searchNote);
    globalContainer.appendChild(panelHeader);

    var buttonRow = document.createElement('div');
    buttonRow.style.cssText = 'display:flex;align-items:center;gap:10px;padding:10px 14px;flex-wrap:wrap;';
    globalContainer.appendChild(buttonRow);

    var settingsBtn = document.createElement('button');
    function updateSettingsBtnLabel(mode) {
        var labels = { gallery: 'Gallery', fullsize: 'Full-size', none: 'No images' };
        settingsBtn.textContent = 'Settings (' + (labels[mode] || mode) + ')';
    }
    storageGet('defaultImageMode', 'gallery').then(updateSettingsBtnLabel);
    settingsBtn.style.cssText = 'padding:8px 16px;background:#6c757d;color:white;border:1px solid #5a6268;border-radius:4px;font-weight:bold;cursor:pointer;';
    settingsBtn.onclick = async function() {
        var currentMode = await storageGet('defaultImageMode', 'gallery');
        var radio = settingsBox.querySelector('input[value="' + currentMode + '"]');
        if (radio) radio.checked = true;
        settingsOverlay.style.display = 'flex';
    };
    buttonRow.appendChild(settingsBtn);

    var saveSelectedBtn = document.createElement('button');
    saveSelectedBtn.textContent = 'Save Selected (0)';
    saveSelectedBtn.style.cssText = 'padding:8px 16px;background:#28a745;color:white;border:1px solid #1e7e34;border-radius:4px;font-weight:bold;cursor:pointer;display:none;';
    saveSelectedBtn.onclick = async function() {
        var checked = Array.from(resultsTable.querySelectorAll('input.cp-row-checkbox:checked'));
        if (!checked.length) return;
        var imageMode = await storageGet('defaultImageMode', 'gallery');
        saveSelectedBtn.disabled = true;
        saveSelectedBtn.textContent = 'Exporting ' + checked.length + ' row(s)...';
        for (var i = 0; i < checked.length; i++) {
            var row = checked[i].closest('tr');
            if (!row) continue;
            var result = await buildRowHtml(row, imageMode);
            var htmlTitle = 'Stock #' + result.stock + ' - ' + result.rowTitle;
            openHtmlInNewTab(getBaseHtml(htmlTitle, result.tableHtml, imageMode !== 'none' ? 'Images should load while online.' : 'Text-only export.', imageMode, searchInfo, sourceUrl));
        }
        saveSelectedBtn.disabled = false;
        updateSaveSelectedBtn();
    };
    buttonRow.appendChild(saveSelectedBtn);

    var dlHtmlGlobalBtn = document.createElement('button');
    dlHtmlGlobalBtn.textContent = 'Save Search Results';
    dlHtmlGlobalBtn.style.cssText = 'padding:8px 16px;background:#007bff;color:white;border:1px solid #0062cc;border-radius:4px;font-weight:bold;cursor:pointer;';
    dlHtmlGlobalBtn.onclick = async function() {
        var imageMode = await storageGet('defaultImageMode', 'gallery');
        var clone = resultsTable.cloneNode(true);
        clone.querySelectorAll('td:last-child,button,th:last-child,input[type="checkbox"]').forEach(function(el) { el.remove(); });
        var firstRow = clone.querySelector('tbody tr:first-child');
        if (firstRow) firstRow.remove();
        if (imageMode === 'none') clone.querySelectorAll('img').forEach(function(img) { img.remove(); });
        openHtmlInNewTab(getBaseHtml('Full Results - ' + searchInfo, clone.outerHTML, imageMode !== 'none' ? 'Images shown are thumbnails from the live page.' : 'Text-only export.', imageMode, searchInfo, sourceUrl));
    };
    buttonRow.appendChild(dlHtmlGlobalBtn);
    resultsTable.parentNode.insertBefore(globalContainer, resultsTable);

    // --- Column headers ------------------------------------------------------
    var headerRow = getRealHeaderRow();
    if (headerRow) {
        var thEx = document.createElement('th');
        thEx.textContent = 'Export';
        thEx.style.cssText = 'text-align:center;white-space:nowrap;';
        headerRow.appendChild(thEx);
        var thCb = document.createElement('th');
        thCb.style.cssText = 'text-align:center;white-space:nowrap;';
        thCb.innerHTML = '<input type="checkbox" id="cp-select-all" title="Select all rows" style="transform:scale(1.3);cursor:pointer;">';
        headerRow.appendChild(thCb);
        document.getElementById('cp-select-all').addEventListener('change', function() {
            resultsTable.querySelectorAll('input.cp-row-checkbox').forEach(function(cb) { cb.checked = this.checked; }, this);
            updateSaveSelectedBtn();
        });
    }

    function updateSaveSelectedBtn() {
        var count = resultsTable.querySelectorAll('input.cp-row-checkbox:checked').length;
        if (count > 0) {
            saveSelectedBtn.style.display = 'inline-block';
            saveSelectedBtn.textContent = 'Save Selected (' + count + ')';
        } else {
            saveSelectedBtn.style.display = 'none';
        }
    }

    // --- Per-row export button + checkbox ------------------------------------
    resultsTable.querySelectorAll('tbody tr').forEach(function(row, index) {
        if (index === 0) return;
        var cells = row.querySelectorAll('td');
        if (cells.length < 7) return;
        var stock = cells[4] ? cells[4].innerText.trim() : '?';
        var hasPhoto = !!row.querySelector('img[onclick^="return popupImg"]');

        var btnCell = document.createElement('td');
        btnCell.style.cssText = 'text-align:center;vertical-align:middle;min-width:160px;padding:6px 10px;';
        var saveBtn = document.createElement('button');
        saveBtn.textContent = 'Save #' + stock;
        saveBtn.title = hasPhoto ? 'This row has photos' : 'No photos for this row';
        saveBtn.style.cssText = 'padding:5px 18px;min-width:120px;font-size:13px;font-weight:bold;color:white;border-radius:4px;cursor:pointer;' +
            'border:' + (hasPhoto ? '1px solid #0062cc' : '1px solid #5a6268') + ';' +
            'background:' + (hasPhoto ? '#007bff' : '#5a9bd4') + ';';
        saveBtn.onclick = async function() {
            var imageMode = await storageGet('defaultImageMode', 'gallery');
            saveBtn.disabled = true;
            saveBtn.textContent = 'Loading...';
            var result = await buildRowHtml(row, imageMode);
            var htmlTitle = 'Stock #' + result.stock + ' - ' + result.rowTitle;
            openHtmlInNewTab(getBaseHtml(htmlTitle, result.tableHtml, imageMode !== 'none' ? 'Images should load while online.' : 'Text-only export.', imageMode, searchInfo, sourceUrl));
            saveBtn.disabled = false;
            saveBtn.textContent = 'Save #' + result.stock;
        };
        btnCell.appendChild(saveBtn);
        row.appendChild(btnCell);

        var cbCell = document.createElement('td');
        cbCell.style.cssText = 'text-align:center;vertical-align:middle;padding:0 10px;';
        var cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'cp-row-checkbox';
        cb.style.cssText = 'transform:scale(1.3);cursor:pointer;';
        cb.addEventListener('change', updateSaveSelectedBtn);
        cbCell.appendChild(cb);
        row.appendChild(cbCell);
    });

});
